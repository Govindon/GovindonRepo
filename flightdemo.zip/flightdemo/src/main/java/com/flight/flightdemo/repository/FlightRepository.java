package com.flight.flightdemo.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.flight.flightdemo.entity.Flight;

@Repository
public interface FlightRepository extends JpaRepository<Flight, Long> {
	/* Assignment 2.1 */
	public List<Flight> findByFlightDateAndFlightInfo_FlightInfoIdIn(Date flightDate,List<Long> flightInfoId);
	
	/* Assignment 2.2 */ 
	public List<Flight> findByFlightDateAndOrigin(Date flightDate, String origin);
}
