package com.flight.flightdemo.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="fare")
public class Fare {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="fare_id")
	private long fareId;
	private String currency;
	private double fare;
	
	public long getFareId() {
		return fareId;
	}
	public void setFareId(long fareId) {
		this.fareId = fareId;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public double getFare() {
		return fare;
	}
	public void setFare(double fare) {
		this.fare = fare;
	}
}
