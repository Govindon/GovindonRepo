package com.flight.flightdemo.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="inventory")
public class Inventory {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="inv_id")
	private long invId;
	private int count;
	public long getInvId() {
		return invId;
	}
	public void setInvId(long invId) {
		this.invId = invId;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
}
