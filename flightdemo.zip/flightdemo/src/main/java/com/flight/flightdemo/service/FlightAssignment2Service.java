package com.flight.flightdemo.service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.flight.flightdemo.entity.Fare;
import com.flight.flightdemo.entity.Flight;
import com.flight.flightdemo.entity.FlightInfo;
import com.flight.flightdemo.entity.Inventory;
import com.flight.flightdemo.repository.FlightInfoRepository;
import com.flight.flightdemo.repository.FlightRepository;

@Service
public class FlightAssignment2Service {
	/* Injecting repository instance */
	@Autowired
	private FlightInfoRepository flightInfoRepository;
	@Autowired
	private FlightRepository flightRepository;

	/* Assignment 2.1 */
	public List<Flight> getAllIndigoFlightDetails() throws ParseException {
		List<FlightInfo> flightInfos = flightInfoRepository.findByAirlineInfos_NameOfAirline("Indigo");
		List<Long> flightInfoId = flightInfos.stream().map(t -> t.getFlightInfoId()).collect(Collectors.toList());
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		Date date = dateFormat.parse("2020-08-21");
		return flightRepository.findByFlightDateAndFlightInfo_FlightInfoIdIn(date, flightInfoId);
	}

	/* Assignment 2.2 */

	public List<Flight> getAllFlightDetailsLeavingDelhi() throws ParseException {
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		Date date = dateFormat.parse("2020-08-21");
		return flightRepository.findByFlightDateAndOrigin(date, "Delhi");
	}

	/* Assignment 2.6 */

	public List<Flight> scheduleFlightsToChennai() throws ParseException {
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		Date date = dateFormat.parse("2020-08-22");
		dateFormat = new SimpleDateFormat("HH:mm:ss");
		Date time = dateFormat.parse("02:20:20");
		List<FlightInfo> flightInfos = flightInfoRepository.findTop3ByAirlineInfos_NameOfAirline("Air India");
		List<FlightInfo> otherFlightInfos = flightInfoRepository.findTop3ByAirlineInfos_NameOfAirlineNot("Air India");
		flightInfos.addAll(otherFlightInfos);
		List<Flight> flights = new ArrayList<>();
		
			
		for(FlightInfo flightInfo:flightInfos) {
			Fare fare = new Fare();
			fare.setCurrency("INR");
			fare.setFare(700);
			Inventory inventory = new Inventory();
			inventory.setCount(200);
			Flight flight = new Flight();
			flight.setDestination("Chennai");
			flight.setDuration("2 hrs 55 mins");
			flight.setFare(fare);
			flight.setFlightDate(date);
			flight.setFlightNumber(flightInfo.getFlightNumber());
			flight.setFlightInfo(flightInfo);
			flight.setFlightTime(time);
			flight.setInventory(inventory);
			flight.setOrigin("Pune");
			flights.add(flight);		
		}
		return flightRepository.saveAll(flights);
	}

	/* POST */
	public Flight SaveFlight(Flight entity) {
		// TODO Auto-generated method stub
		return flightRepository.save(entity) ;
	}
	
	

}
