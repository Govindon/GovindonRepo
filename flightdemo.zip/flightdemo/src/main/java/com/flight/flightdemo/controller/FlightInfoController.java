package com.flight.flightdemo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.flight.flightdemo.entity.FlightInfo;
import com.flight.flightdemo.service.FlightInfoService;

@RestController
@RequestMapping(path="flightInfo")
public class FlightInfoController {
	/* Injecting repository instance */
	@Autowired 
	private FlightInfoService flightInfoService;
	
	 /* REST end point mapping */
	@GetMapping(value = "/getAll",produces = {"application/json","application/xml"})
	public List<FlightInfo> getAllFlightInfo() {
		return flightInfoService.getAllFlightInfo();
	}

}
