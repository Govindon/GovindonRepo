package com.flight.flightdemo.controller;

import java.text.ParseException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.flight.flightdemo.entity.Flight;
import com.flight.flightdemo.service.FlightAssignment2Service;
import com.flight.flightdemo.service.FlightService;

@RestController
@RequestMapping(path = "flight")
public class FlightController {
	/* Injecting repository instance */
	@Autowired
	private FlightService flightService;
	@Autowired
	private FlightAssignment2Service flightAssignment2Service;

	/* REST end point mapping */
	@GetMapping(value = "/getAll",produces = {"application/json","application/xml"})
	public List<Flight> getAllFlight() {
		return flightService.getAllFlight();
	}
	
	/* Assignment 2.1 */
	@GetMapping(value = "/getFlightIndigo",produces = {"application/json","application/xml"})
	public List<Flight> getFlightIndigo() throws ParseException {
		return flightAssignment2Service.getAllIndigoFlightDetails();
	}
	
	/* Assignment 2.2 */
	@GetMapping(value = "/getFlightLeavingfromDelhi",produces = {"application/json","application/xml"})
	public List<Flight> getFlightLeavingfromDelhi() throws ParseException {
		return flightAssignment2Service.getAllFlightDetailsLeavingDelhi();
	}
	
	/* Assignment 2.6 */
	@GetMapping(value = "/scheduleFlight",produces = {"application/json","application/xml"})
	public List<Flight> scheduleFlightLeavingToChennai() throws ParseException {
		return flightAssignment2Service.scheduleFlightsToChennai();
	}

	
	/* Assignment 5 - POST Mapping */
	@PostMapping(value = "/SaveFlight")
	public Flight postMethodName(@RequestBody Flight entity) {
		//TODO: process POST request
		
		return flightAssignment2Service.SaveFlight(entity);
	}

}
