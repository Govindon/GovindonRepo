package com.flight.flightdemo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.flight.flightdemo.entity.FlightInfo;

@Repository
public interface FlightInfoRepository extends JpaRepository<FlightInfo, Long> {

	/* Assignment 2.1 */
	public List<FlightInfo> findByAirlineInfos_NameOfAirline(String nameOfAirline);
	//public List<FlightInfo> findByAirlineInfos_NameOfAirline();
	/* Assignment 2.6 */
	public List<FlightInfo> findTop3ByAirlineInfos_NameOfAirline(String nameOfAirline);
	public List<FlightInfo> findTop3ByAirlineInfos_NameOfAirlineNot(String nameOfAirline);
}
