package com.flight.flightdemo.entity;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name = "flight_info")
public class FlightInfo {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "flight_infoid")
	private long flightInfoId;

	@Column(name = "flight_number")
	private String flightNumber;

	@Column(name = "flight_type")
	private String flightType;

	@Column(name = "numberof_seats")
	private int numberOfSeats;

	@ManyToMany
	@JoinTable(name = "flights_info", joinColumns = { @JoinColumn(name = "flight_infoid") }, inverseJoinColumns = {
			@JoinColumn(name = "airline_id") })
	private List<AirlineInfo> airlineInfos;

	public long getFlightInfoId() {
		return flightInfoId;
	}

	public void setFlightInfoId(long flightInfoId) {
		this.flightInfoId = flightInfoId;
	}

	public String getFlightNumber() {
		return flightNumber;
	}

	public void setFlightNumber(String flightNumber) {
		this.flightNumber = flightNumber;
	}

	public String getFlightType() {
		return flightType;
	}

	public void setFlightType(String flightType) {
		this.flightType = flightType;
	}

	public int getNumberOfSeats() {
		return numberOfSeats;
	}

	public void setNumberOfSeats(int numberOfSeats) {
		this.numberOfSeats = numberOfSeats;
	}

	public List<AirlineInfo> getAirlineInfos() {
		return airlineInfos;
	}

	public void setAirlineInfos(List<AirlineInfo> airlineInfos) {
		this.airlineInfos = airlineInfos;
	}

}
