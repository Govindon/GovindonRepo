package com.flight.flightdemo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.flight.flightdemo.entity.Flight;
import com.flight.flightdemo.repository.FlightRepository;

@Service
public class FlightService {
	/* Injecting repository instance */
	@Autowired
	private FlightRepository flightRepository;

	public List<Flight> getAllFlight() {
		return flightRepository.findAll();
	}
}
